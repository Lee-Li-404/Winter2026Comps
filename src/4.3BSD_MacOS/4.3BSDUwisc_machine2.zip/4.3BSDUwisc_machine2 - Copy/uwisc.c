#include <stdio.h>


void main(void)
{
printf("Launching 4.3 BSD Uwisc\n");
system("start 4.3BSDuwisc vax780.ini");
_sleep (3000);
system("start ttermpro localhost 40315 /K=.\\ibmkeyb.cnf");
}