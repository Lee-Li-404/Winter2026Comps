Welcome to this BETA test of SIM-H 3.8-1 on Windows with BSD 4.3
from the University of Wisconsin.

This release is a 4.3 BSD with the NFS & VFS code from SUN rolled in.


The main website is http://sourceforge.net/projects/bsd42/

There is networking in this release.. You can telnet into the vax
by telnetting into port 42323.  If you want more ports, or to change
the ports you will need the source for the SLiRP version of SIMH
which should be on the sourceforge page for simh:
http://sourceforge.net/projects/simh/


By default you should install *everything*.  The config
file is setup to mount a /home drive seperate from the 
Operation System.  This will allow for a somewhat painless
recovery if you trash the OS.

On uninstallation you will have the option of keeping your
home disk.



This is the configuation file that I'm using.
------
set cpu idle
set cpu 16M
set rq0 dis
set rq1 dis
set rq2 dis
set rq3 dis
set rp0 rp06
att rp0 bsd43.disk
set rp1 dis
set rp2 dis
set rp3 dis
set rp4 dis
set rp5 dis
set rp6 dis
set rp7 dis
set lpt dis
set hk dis
set ry dis
set rl dis
set tq dis
set tu dis
;att ts 43.tap
set tti 7b
set tto 7b
set xu ena
att xu slirp
set con telent=42221
load -o boothp 0
d r10 0
d r11 0
run 2
-------

By default on windows the console will not handle ascii correctly.  
I have enclosed a copy of Tera Term Pro that will connect on the correct port,
the link is the "Attach a PTY".  Just wait for the Operating System
to boot up to the login prompt.  You can use any telnet program
that you wish, just connect to the localhost on port 42221.

I have rigged the emulator to exit on reboots, so that way you can interrupt it with 
control+e and mount tape images, etc to transfer data into the emulator.  I have
set the emulator up with 16mb of ram, if you need more, simply edit the vax780.ini file.

The OS is installed onto a HP/RP06 disk.  I did this to keep the footprint small, unlike the
prior releases of this... If you want to add more disks, again modify the vax780.ini file.

This version of SIMH also has a minor patch that restored the idle to the prior IPL/timing
that was present in SIMH-3.7-3.  I forget where it is exactly, but I did post it on the SIMH
mailing lists:  http://mailman.trailing-edge.com/pipermail/simh/


*Please note that this program is nowhere Vista compliant.  The user data is
dumped into the program file directory (bad) so you must run this program elevated
as Administrator! (right click on the program link, and choose run as Administrator).
x